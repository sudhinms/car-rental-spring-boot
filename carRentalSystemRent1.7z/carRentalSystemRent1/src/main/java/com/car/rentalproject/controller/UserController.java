package com.car.rentalproject.controller;

import com.car.rentalproject.dataTransferObject.CarDto.CarBrandInfoData;
import com.car.rentalproject.dataTransferObject.CarDto.CarDetails;
import com.car.rentalproject.dataTransferObject.CarDto.CarInfoData;
import com.car.rentalproject.dataTransferObject.UserDto.*;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.FileReadWriteException;
import com.car.rentalproject.exceptions.PasswordNotMatchException;
import com.car.rentalproject.repository.*;
import com.car.rentalproject.security.JwtServices;
import com.car.rentalproject.services.BookingService;
import com.car.rentalproject.services.UserServices;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private JwtServices jwtServices;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserServices userServices;



    @PostMapping("/registration")
    public ResponseEntity<?> save(@ModelAttribute Users users, @RequestParam("image") MultipartFile file) throws IOException, FileReadWriteException {
        return userServices.registration(users, file);

    }


    @PostMapping("/login")
    public String authenticateGetToken(@RequestBody AuthRequest authRequest) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
        if (authentication.isAuthenticated()) {

            return jwtServices.GenerateToken(authRequest.getUsername());

        } else {
            throw new UsernameNotFoundException("user not found");
        }

    }

    @GetMapping("get/profile")
    public List<UserProfileDto> getUserInfo(@RequestHeader(name = "Authorization") String token) {
        String currentUserEmail = jwtServices.extractUsernameFromToken(token.substring(7));
        Optional<Users> user = userRepository.findByEmail(currentUserEmail);
        if (user.isEmpty()) {
            throw new UsernameNotFoundException("user not found");
        }
        return userServices.getUser(user.get());
    }


    @PutMapping("get/changePassword")
    public ResponseEntity<?> updatePassword(@RequestBody @Valid PasswordDto passwordDto,
                                            @RequestHeader(name = "Authorization") String token) throws PasswordNotMatchException {
        String email = jwtServices.extractUsernameFromToken(token.substring(7));
        return userServices.updatePassword(email, passwordDto);
    }

    @PatchMapping("get/update")
    public ResponseEntity<?> updateProfile(@ModelAttribute @Valid UserUpdateDto userdata,
                                               @RequestParam("image") MultipartFile image,
                                               @RequestHeader(name = "Authorization") String token) throws IOException, FileReadWriteException {
        String email = jwtServices.extractUsernameFromToken(token.substring(7));
        return userServices.updateUserData(userdata, email, image);
    }

    @GetMapping("view/brand-info")
    public ResponseEntity<List<CarBrandInfoData>> getBrandInfo() {
        List<CarBrandInfoData> brandInfoList = bookingService.getAllBrandInfoDTO();
        return ResponseEntity.ok(brandInfoList);
    }

    @GetMapping("view/car-info")
    public ResponseEntity<List<CarInfoData>> getCarInfo() {
        List<CarInfoData> carInfoList = bookingService.getAllCarInfoData();
        return ResponseEntity.ok(carInfoList);
    }

    @GetMapping("view/All-cars-info")
    public List<CarDetails> getAllCars() {
        return bookingService.getAllCarDetails();
    }


}


