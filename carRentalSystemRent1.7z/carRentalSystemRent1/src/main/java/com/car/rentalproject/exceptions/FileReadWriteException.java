package com.car.rentalproject.exceptions;

public class FileReadWriteException extends Throwable {
    public FileReadWriteException(String s) {
        super(s);
    }
}

