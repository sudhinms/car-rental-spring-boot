package com.car.rentalproject.services;

import com.car.rentalproject.dataTransferObject.UserDto.PasswordDto;
import com.car.rentalproject.dataTransferObject.UserDto.UserProfileDto;
import com.car.rentalproject.dataTransferObject.UserDto.UserUpdateDto;
import com.car.rentalproject.dataTransferObject.UserDto.UserData;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.FileReadWriteException;
import com.car.rentalproject.exceptions.PasswordNotMatchException;
import com.car.rentalproject.repository.PaymentRepository;
import com.car.rentalproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class UserServices {
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PaymentRepository paymentRepository;


    public ResponseEntity<?> registration(Users users, MultipartFile file) throws  FileReadWriteException {
        if(userRepository.existsByEmailOrId(users.getEmail(), users.getId())){
            return new ResponseEntity<>("There is an existing user with the same email Or ID....Please try again...",HttpStatus.ACCEPTED);
        }

        users.setPassword(passwordEncoder.encode(users.getPassword()));
        return  validateAndSetImage(users,file);

    }
    private ResponseEntity<?> validateAndSetImage(Users users, MultipartFile file) throws FileReadWriteException {
        if(file!=null){
            try {
                if (!Objects.requireNonNull(file.getContentType()).startsWith("image/")) {
                    return ResponseEntity.badRequest().body("Only images are allowed");
                }
                users.setProfileImage(file.getBytes());
            }catch (Exception e){
                throw new FileReadWriteException("Can't write image data to db");
            }
        }
        userRepository.save(users);
        return new ResponseEntity<>("Created Successfully",HttpStatus.CREATED);
    }

    public ResponseEntity<?> updateUserData(UserUpdateDto userdata, String email, MultipartFile file) throws IOException, FileReadWriteException {
        Optional<Users> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isPresent()) {
            Users existingUser = optionalUser.get();
            existingUser.setName(userdata.getName());
            existingUser.setAge(userdata.getAge());
            existingUser.setAddress(userdata.getAddress());
            existingUser.setDate(userdata.getDate());
            return  validateAndSetImage(existingUser,file);
            } else {
                return ResponseEntity.notFound().build();
            }
        }


    public List<UserProfileDto> getUser(Users user) {
        return Stream.of(user)
            .map(UserProfileDto::new)
            .collect(Collectors.toList());

    }

public ResponseEntity<?> updatePassword(String email, PasswordDto passwordDto) throws PasswordNotMatchException {
    Optional<Users> optionalUser = userRepository.findByEmail(email);
    if (optionalUser.isPresent()) {
        Users userInfo = optionalUser.get();
        if (!passwordEncoder.matches(passwordDto.getOldPassword(), userInfo.getPassword())) {
            throw new PasswordNotMatchException("Incorrect password for user : " + email);
        }
        if (!Objects.equals(passwordDto.getNewPassword(), passwordDto.getConfirmPassword())) {
            throw new PasswordNotMatchException("Confirm password not match with new password");
        }
        userInfo.setPassword(passwordEncoder.encode(passwordDto.getNewPassword()));
        userRepository.save(userInfo);
        return new ResponseEntity<>("Password updated successfully..", HttpStatus.OK);
    } else {
        return new ResponseEntity<>("Email not found.", HttpStatus.NOT_FOUND);
    }
}
    public void deleteUser(long userId) {
        Users user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            ResponseEntity.status(404).body("User not found");
            return;
        }
        List<Booking> userBookings = user.getBookings();
        if (!userBookings.isEmpty()) {
            ResponseEntity.status(400).body("Cannot delete user with existing bookings");
            return;
        }
        userRepository.deleteById(userId);
        ResponseEntity.ok("User deleted successfully");
    }

}
