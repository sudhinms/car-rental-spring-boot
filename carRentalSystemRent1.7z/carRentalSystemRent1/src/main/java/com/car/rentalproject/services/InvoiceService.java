package com.car.rentalproject.services;


import com.car.rentalproject.entity.Payment;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.BookingIdNotFoundException;
import com.car.rentalproject.repository.PaymentRepository;
import com.car.rentalproject.repository.UserRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.io.ByteArrayOutputStream;

@Service
public class InvoiceService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PaymentRepository paymentRepository;

    public byte[] generateInvoice(String email, long paymentId) {
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Document document = new Document();
            PdfWriter.getInstance(document, outputStream);
            document.open();
            String invoiceContext = generateInvoiceContext(email, paymentId);
            document.add(new

                    Paragraph(invoiceContext));
            document.close();
            return outputStream.toByteArray();
        } catch (DocumentException e) {
            throw new RuntimeException(e);
        }
    }


    private String generateInvoiceContext(String email, long paymentId) throws BookingIdNotFoundException {
        Users user = userRepository.findByEmail(email)
                .orElseThrow(() -> new BookingIdNotFoundException("User not found with email: " + email));

        Payment paymentDetails = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new BookingIdNotFoundException("Payment details not found for transaction ID: " + paymentId));

        if (!Long.valueOf(user.getId()).equals(paymentDetails.getUser().getId())) {
            throw new BookingIdNotFoundException("User ID does not match with payment details for transaction ID: " + paymentId);
        }

        StringBuilder invoiceContext = new StringBuilder();

        if (paymentDetails.getPaymentId() == paymentId) {
            invoiceContext.append("_______________________________Invoice Details___________________________\n ");
            invoiceContext.append("Customer Id      :  ").append(user.getId()).append("\n");
            invoiceContext.append("Name       :  ").append(user.getName()).append("\n");
            invoiceContext.append("Email      :  ").append(user.getEmail()).append("\n");
            invoiceContext.append("Booking  Id :  ").append(paymentDetails.getBookingIds()).append("\n");
            //invoiceContext.append("Car Id  :  ").append(paymentDetails.getCarInfoIds()).append("\n");
            invoiceContext.append("Transaction Id :  ").append(paymentId).append("\n");
            invoiceContext.append("Transaction Date :  ").append(paymentDetails.getPaymentDate()).append("\n");
            double GST = paymentDetails.getAmount() * 0.02;
            invoiceContext.append("Total Amount      :  ").append(paymentDetails.getAmount()).append("\n");
            invoiceContext.append("GST         : ").append(GST).append("\n");
            invoiceContext.append("____________________________\n ");
            double totalAmount = paymentDetails.getAmount() + GST;
            invoiceContext.append("Total amount    : ").append(totalAmount);
        }

        return invoiceContext.toString();
    }
}