package com.car.rentalproject.services;

import com.car.rentalproject.dataTransferObject.CarDto.CarReturnDto;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.CarInfo;
import com.car.rentalproject.entity.CarReturnDetails;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.BookingRepository;
import com.car.rentalproject.repository.CarInfoRepository;
import com.car.rentalproject.repository.CarReturnDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class CarReturnServices {
    @Autowired
    private CarReturnDetailsRepository carReturnDetailsRepository;
    @Autowired
    private CarInfoRepository carInfoRepository;
    @Autowired
    private BookingRepository bookingRepository;

    public ResponseEntity<?> returnCars(long bookingId) {
            Booking booking = bookingRepository.findById(bookingId).orElse(null);
            if (booking != null) {
                CarReturnDetails carReturnDetails = new CarReturnDetails();
                carReturnDetails.setBooking(booking);
                LocalDate currentDate = LocalDate.now();
                //LocalDate returnDate = LocalDate.of(booking.getReturnDate());
                 LocalDate returnDate=booking.getReturnDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                carReturnDetails.setReturnArrivedDate(currentDate);

                if (currentDate.isAfter(returnDate)) {
                    long overdueDays = ChronoUnit.DAYS.between(returnDate, currentDate);
                    long penaltyAmount = overdueDays * 500;
                    carReturnDetails.setPenaltyAmount(penaltyAmount);
                    carReturnDetailsRepository.save(carReturnDetails);

                    return ResponseEntity.ok("Pay $" + penaltyAmount + " for " + overdueDays + " overdue days.");
                } else {
                    carReturnDetails.setReturnStatus("Returned");
                    carReturnDetailsRepository.save(carReturnDetails);

                    // Increase stock in CarInfo table
                    CarInfo carInfo = carReturnDetails.getBooking().getCarInfo();
                    carInfo.setStock(carInfo.getStock() + 1);
                    carInfoRepository.save(carInfo);

                    return ResponseEntity.ok("Return request accepted.");
                }
            } else {
                return ResponseEntity.badRequest().body("Booking  not found.");
            }
        }

    }


//    public ResponseEntity<?>extendReturn(long bookingId){
//        Optional<CarReturnDetails> carReturnDetails = carReturnDetailsRepository.findByBookingId(bookingId);
//            if (carReturnDetails.isPresent()) {
//            CarReturnDetails carReturnInfo = carReturnDetails.get();
//            //carReturnInfo.setReturnDate(carReturnInfo.getReturnDate().plusMonths(6));
//            CarInfo carInfo = carReturnInfo.getBooking().getCarInfo();
//            //carReturnInfo.setOverDueRent(carInfo.getAmount());
//            carReturnDetailsRepository.save(carReturnInfo);
//            return ResponseEntity.ok("Car return Date extended, pay OverDueRent Immediately");
//        }
//
//            return new ResponseEntity<>("Booking ID not found.", HttpStatus.NOT_FOUND);
//    }



