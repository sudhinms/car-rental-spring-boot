package com.car.rentalproject.controller;

import com.car.rentalproject.security.JwtServices;
import com.car.rentalproject.services.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/invoice")
public class InvoiceController {
    @Autowired
    private InvoiceService invoiceService;
    @Autowired
    private JwtServices jwtService;
    @GetMapping("/download-invoice/{paymentId}")
    public ResponseEntity<byte[]> downloadInvoice(@RequestHeader(name = "Authorization") String token, @PathVariable long paymentId) {
        String email = jwtService.extractUsernameFromToken(token.substring(7));
        byte[] invoiceContext = invoiceService.generateInvoice(email, paymentId);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_PDF);
        return new ResponseEntity<>(invoiceContext, httpHeaders, HttpStatus.OK);
    }
}