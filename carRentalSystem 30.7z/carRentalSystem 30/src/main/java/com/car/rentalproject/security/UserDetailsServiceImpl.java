package com.car.rentalproject.security;

import com.car.rentalproject.entity.Users;
import com.car.rentalproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Optional;


@Component
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository studentRepository;

    @Override
    public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
        Optional<Users> userinfo=studentRepository.findByEmail(name);
        return userinfo.map(CustomUserDetails::new).orElseThrow(()->new UsernameNotFoundException("user not found"+name));
    }
}
