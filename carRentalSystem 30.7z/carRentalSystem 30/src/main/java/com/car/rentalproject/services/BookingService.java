package com.car.rentalproject.services;

import com.car.rentalproject.dataTransferObject.CarDto.*;
import com.car.rentalproject.dataTransferObject.UserDto.UserData;
import com.car.rentalproject.entity.*;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BookingService {
    @Autowired
    private CarBrandInfoRepository carBrandRepository;
    @Autowired
    private CarInfoRepository carInfoRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private PaymentRepository paymentRepository;


    public ResponseEntity<String> bookCar(long customerId, long carInfoId) throws UserNotFoundException {
        Users user = userRepository.findById(customerId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + customerId));
        CarInfo carInfo = carInfoRepository.findById(carInfoId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Car not found with ID: " + carInfoId));
        if (carInfo.getStock() <= 0) {
            return ResponseEntity.ok(" Stock is not available");
        }

        Booking booking = new Booking();
        booking.setUsers(user);
        booking.setCarInfo(carInfo);
        booking.setBookingTime(LocalDateTime.now());
        booking.setStatus("booked");

        bookingRepository.save(booking);

        if (user.getBookings() == null) {
            user.setBookings(new ArrayList<>());
        }
        user.getBookings().add(booking);
        user.setBookingStatus("Booked");
        userRepository.save(user);

        if (carInfo.getBookings() == null) {
            carInfo.setBookings(new ArrayList<>());
        }
        carInfo.getBookings().add(booking);
        carInfo.setStock(carInfo.getStock() - 1);
        carInfoRepository.save(carInfo);

        return ResponseEntity.ok("Car booked successfully.");
    }

    public ResponseEntity<String> deleteBooking(long userId, long bookingId) {
        Optional<Booking> optionalBooking = bookingRepository.findByIdAndUsersId(bookingId, userId);

        if (optionalBooking.isEmpty()) {
            return ResponseEntity.status(404).body("Booking not found for the given user and booking ID");
        }
        Booking booking = optionalBooking.get();
        if (!booking.getStatus().equals("booked")) {
            return ResponseEntity.status(400).body("Cannot delete a booking with status  'payed'");
        }

        bookingRepository.delete(booking);
        return ResponseEntity.ok("Booking deleted successfully");
    }

    public List<BookingData> mapToBookingInfoListUser(List<Booking> bookings) {
        return bookings.stream()
                .map(BookingData::new)
                .collect(Collectors.toList());
    }

    public List<CarDetails> getAllCarDetails() {
        List<CarBrandInfo> carBrandDetails = carBrandRepository.findAll();
        return carBrandDetails.stream()
                .flatMap(carBrandInfo -> carBrandInfo.getCarDetails().stream())
                .toList();
    }

    public List<CarBrandInfoData> getAllBrandInfoDTO() {
        List<CarBrandInfo> brandInfoList = carBrandRepository.findAll();
        return brandInfoList.stream()
                .map(brandInfo -> new CarBrandInfoData(brandInfo.getId(), brandInfo.getCarBrandName()))
                .collect(Collectors.toList());
    }

    public List<CarInfoData> getAllCarInfoData() {
        List<CarInfo> carInfoList = carInfoRepository.findAll();
        return carInfoList.stream()
                .map(carInfo -> {
                    long brandId = (carInfo.getCarBrand() != null) ? carInfo.getCarBrand().getId() : 0L;
                    return new CarInfoData(
                            carInfo.getId(),
                            carInfo.getCarName(),
                            carInfo.getAmount(),
                            brandId
                    );
                })
                .collect(Collectors.toList());
    }

    public ResponseEntity<String> userPayment(String currentUserEmail, PaymentDetails paymentDetails) {
        Optional<Users> optionalUser = userRepository.findByEmail(currentUserEmail);
        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            List<Booking> userBookings = bookingRepository.findByUsersAndStatusNot(user, "Payed");
            if (!userBookings.isEmpty()) {
                double totalBookingAmount = userBookings.stream()
                        .mapToDouble(booking -> booking.getCarInfo().getAmount())
                        .sum();

                // Create a list to store all the carInfoIds
                List<Long> carInfoIds = new ArrayList<>();
                List<Long> bookingIds = new ArrayList<>();


                for (Booking booking : userBookings) {

                     booking.setStatus("Payed");
                    // Add the carInfoId to the list
                    carInfoIds.add(booking.getCarInfo().getId());
                    bookingIds.add(booking.getId());
                }

                // Convert the list of carInfoIds to a comma-separated string
                String carInfoIdsString = carInfoIds.stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(", "));

                String bookingIdsString = bookingIds.stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(", "));

                // Save the carInfoIds to the payment table
                Payment payment = new Payment();
                payment.setUser(user);
                payment.setAmount(totalBookingAmount);
                payment.setPaymentDate(LocalDateTime.now());
                payment.setPaymentStatus("success");
                payment.setAccountHolderName(paymentDetails.getAccountHolderName());
                payment.setAccountNumber(paymentDetails.getAccountNumber());
                payment.setIfscCode(paymentDetails.getIfscCode());
                payment.setCarInfoIds(carInfoIdsString);
                payment.setBookingIds(bookingIdsString);
                paymentRepository.save(payment);
                bookingRepository.saveAll(userBookings);
                return ResponseEntity.ok("Payment successful");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No unpaid bookings found for the user");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
    }

    public List<PaymentDto> getPaymentDetailsForUser(long userId) {
        Optional<Users> optionalUser = userRepository.findById(userId);

        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            List<Payment> userPayments = paymentRepository.findByUser(user);

            if (!userPayments.isEmpty()) {
                return userPayments.stream()
                        .map(payment -> new PaymentDto(
                                user.getId(),
                                payment.getPaymentId(),
                                payment.getAmount(),
                                payment.getPaymentDate(),
                                payment.getPaymentStatus()
                        ))
                        .collect(Collectors.toList());
            } else {
                throw new IllegalStateException("No payments found for the user");
            }
        } else {
            throw new IllegalArgumentException("User not found");
        }
    }

}

