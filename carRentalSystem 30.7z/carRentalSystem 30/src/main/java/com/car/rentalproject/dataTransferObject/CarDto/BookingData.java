package com.car.rentalproject.dataTransferObject.CarDto;



import com.car.rentalproject.entity.Booking;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookingData {


    private long bookingId;
    private LocalDateTime bookingTime;
    private long customerId;
    private long carInfoId;
    private String status;

    public BookingData(Booking booking) {
        this.bookingId = booking.getId();
        this.bookingTime = booking.getBookingTime();
        this.customerId = booking.getUsers().getId();
        this.carInfoId = booking.getCarInfo().getId();
        this.status = booking.getStatus();
    }


}