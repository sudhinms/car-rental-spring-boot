package com.car.rentalproject.controller;


import com.car.rentalproject.repository.CarReturnDetailsRepository;
import com.car.rentalproject.repository.UserRepository;
import com.car.rentalproject.security.JwtServices;
import com.car.rentalproject.services.BookingService;
import com.car.rentalproject.services.CarReturnServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/return")

public class CarReturnController {

    @Autowired
    private CarReturnServices returnServices;
    @Autowired
    private CarReturnDetailsRepository carReturnDetailsRepository;
    @Autowired
    private JwtServices jwtServices;
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/car/{bookingId}")
    public ResponseEntity<?> returnCars(@RequestHeader(name = "Authorization") String token,@PathVariable long bookingId) {
        String currentUserEmail = jwtServices.extractUsernameFromToken(token.substring(7));
        return returnServices.returnCars(currentUserEmail,bookingId);
    }

}