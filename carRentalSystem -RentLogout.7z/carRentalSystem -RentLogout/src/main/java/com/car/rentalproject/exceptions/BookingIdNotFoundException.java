package com.car.rentalproject.exceptions;

public class BookingIdNotFoundException extends RuntimeException {
    public BookingIdNotFoundException(String s) {
        super(s);
    }
}
