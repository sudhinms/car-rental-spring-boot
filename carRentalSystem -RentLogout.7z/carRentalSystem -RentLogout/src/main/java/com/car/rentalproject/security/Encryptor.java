package com.car.rentalproject.security;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Arrays;
import java.util.Base64;

public class Encryptor {
    private static final String SECRET_KEY = "6ce0eb78af5d6d6067830a5f0bea2343003a96b2760bf8f4cb1c4b2463a55c1e";

    public static String encrypt(String cardNumber) throws Exception {
        SecretKeySpec secretKey = getSecretKey();
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(String.valueOf(cardNumber).getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    public static SecretKeySpec getSecretKey() {
        byte[] key = SECRET_KEY.getBytes();
        key = Arrays.copyOf(key, 16);
        return new SecretKeySpec(key, "AES");
    }
}
