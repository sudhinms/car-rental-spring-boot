package com.car.rentalproject.services;

import com.car.rentalproject.dataTransferObject.CarDto.CarReturnDto;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.CarInfo;
import com.car.rentalproject.entity.CarReturnDetails;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.BookingRepository;
import com.car.rentalproject.repository.CarInfoRepository;
import com.car.rentalproject.repository.CarReturnDetailsRepository;
import com.car.rentalproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class CarReturnServices {
    @Autowired
    private CarReturnDetailsRepository carReturnDetailsRepository;
    @Autowired
    private CarInfoRepository carInfoRepository;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private UserRepository userRepository;

    public ResponseEntity<?> returnCars(String currentUserEmail,long bookingId) {
        Optional<Users> optionalUser = userRepository.findByEmail(currentUserEmail);
        if (optionalUser.isPresent()) {
            Users user=optionalUser.get();
            Booking booking = bookingRepository.findByIdAndUsersId(bookingId,user.getId()).orElse(null);
            if (booking != null) {
                if (booking.getStatus().equals("Payed")) {
                    CarReturnDetails carReturnDetails = new CarReturnDetails();
                    carReturnDetails.setBooking(booking);
                    LocalDate currentDate = LocalDate.now();
                    LocalDate returnDate = booking.getReturnDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    carReturnDetails.setReturnArrivedDate(currentDate);

                    if (currentDate.isAfter(returnDate)) {
                        long overdueDays = ChronoUnit.DAYS.between(returnDate, currentDate);
                        long penaltyAmount = overdueDays * 500;
                        carReturnDetails.setPenaltyAmount(penaltyAmount);
                        carReturnDetailsRepository.save(carReturnDetails);

                        return ResponseEntity.ok("Pay $" + penaltyAmount + " for " + overdueDays + " overdue days.");
                    } else {
                        carReturnDetails.setReturnStatus("Returned");
                        carReturnDetailsRepository.save(carReturnDetails);
                        booking.setStatus("Returned");
                        bookingRepository.save(booking);

                        // Increase stock in CarInfo table
                        CarInfo carInfo = carReturnDetails.getBooking().getCarInfo();
                        carInfo.setStock(carInfo.getStock() + 1);
                        carInfoRepository.save(carInfo);

                        return ResponseEntity.ok("Return request accepted.");
                    }
                }
                if (booking.getStatus().equals("Returned")) {
                    return ResponseEntity.badRequest().body("This Booking Id Car is already returned");
                } else {
                    return ResponseEntity.badRequest().body("This Booking is unpaid or Cancelled");
                }
            } else {
                return ResponseEntity.badRequest().body("This Booking Id is not valid for this User");
            }
        }
       else {
            return ResponseEntity.badRequest().body("User  not found");
        }
        }

    }






