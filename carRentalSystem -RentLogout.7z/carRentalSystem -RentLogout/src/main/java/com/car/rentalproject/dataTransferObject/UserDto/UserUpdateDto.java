package com.car.rentalproject.dataTransferObject.UserDto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserUpdateDto {
    private long id;
    private String name;
    private int age;
    private String address;
    private Date date;
    @Column(nullable = false)
    private byte profileImage;

}
