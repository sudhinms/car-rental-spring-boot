package com.car.rentalproject.services;

import com.car.rentalproject.dataTransferObject.CarDto.*;
import com.car.rentalproject.dataTransferObject.UserDto.UserData;
import com.car.rentalproject.entity.*;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BookingService {
    @Autowired
    private CarBrandInfoRepository carBrandRepository;
    @Autowired
    private CarInfoRepository carInfoRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private PaymentRepository paymentRepository;


    public ResponseEntity<String> bookCar(long customerId, long carInfoId) throws UserNotFoundException {
        Users user = userRepository.findById(customerId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + customerId));
        CarInfo carInfo = carInfoRepository.findById(carInfoId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Car not found with ID: " + carInfoId));
        if (carInfo.getStock() <= 0) {
            return ResponseEntity.ok(" Stock is not available");
        }

        Booking booking = new Booking();
        booking.setUsers(user);
        booking.setCarInfo(carInfo);
        booking.setBookingTime(LocalDateTime.now());
        booking.setStatus("booked");

        bookingRepository.save(booking);

        if (user.getBookings() == null) {
            user.setBookings(new ArrayList<>());
        }
        user.getBookings().add(booking);
        user.setBookingStatus("Booked");
        userRepository.save(user);

        if (carInfo.getBookings() == null) {
            carInfo.setBookings(new ArrayList<>());
        }
        carInfo.getBookings().add(booking);
        carInfo.setStock(carInfo.getStock() - 1);
        carInfoRepository.save(carInfo);

        return ResponseEntity.ok("Car booked successfully.");
    }

    public ResponseEntity<String> deleteBooking(long userId, long bookingId) {
        Optional<Booking> optionalBooking = bookingRepository.findByIdAndUsersId(bookingId, userId);

        if (optionalBooking.isEmpty()) {
            return ResponseEntity.status(404).body("Booking not found for the given user and booking ID");
        }
        Booking booking = optionalBooking.get();
        if (!booking.getStatus().equals("booked")) {
            return ResponseEntity.status(400).body("Cannot delete a booking with status other than 'booked'");
        }

        bookingRepository.delete(booking);
        return ResponseEntity.ok("Booking deleted successfully");
    }

    public List<BookingData> mapToBookingInfoListUser(List<Booking> bookings) {
        return bookings.stream()
                .map(BookingData::new)
                .collect(Collectors.toList());
    }

    public List<CarDetails> getAllCarDetails() {
        List<CarBrandInfo> carBrandDetails = carBrandRepository.findAll();
        return carBrandDetails.stream()
                .flatMap(carBrandInfo -> carBrandInfo.getCarDetails().stream())
                .toList();
    }

    public List<CarBrandInfoData> getAllBrandInfoDTO() {
        List<CarBrandInfo> brandInfoList = carBrandRepository.findAll();
        return brandInfoList.stream()
                .map(brandInfo -> new CarBrandInfoData(brandInfo.getId(), brandInfo.getCarBrandName()))
                .collect(Collectors.toList());
    }

    public List<CarInfoData> getAllCarInfoData() {
        List<CarInfo> carInfoList = carInfoRepository.findAll();
        return carInfoList.stream()
                .map(carInfo -> {
                    long brandId = (carInfo.getCarBrand() != null) ? carInfo.getCarBrand().getId() : 0L;
                    return new CarInfoData(
                            carInfo.getId(),
                            carInfo.getCarName(),
                            carInfo.getAmount(),
                            brandId
                    );
                })
                .collect(Collectors.toList());
    }

    public ResponseEntity<String> userPayment(String currentUserEmail, PaymentDetails paymentDetails) {
        Optional<Users> optionalUser = userRepository.findByEmail(currentUserEmail);
        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            List<Booking> userBookings = bookingRepository.findByUsersAndStatusNot(user, "Payed");
            if (!userBookings.isEmpty()) {
                double totalBookingAmount = userBookings.stream()
                        .mapToDouble(booking -> booking.getCarInfo().getAmount())
                        .sum();

                // Create a list to store all the carInfoIds
                List<Long> carInfoIds = new ArrayList<>();
                List<Long> bookingIds = new ArrayList<>();


                for (Booking booking : userBookings) {
                    Payment payment = new Payment();
                    payment.setUser(user);
                    payment.setAmount(booking.getCarInfo().getAmount());
                    payment.setPaymentDate(LocalDateTime.now());
                    payment.setPaymentStatus("success");
                    payment.setAccountHolderName(paymentDetails.getAccountHolderName());
                    payment.setAccountNumber(paymentDetails.getAccountNumber());
                    payment.setIfscCode(paymentDetails.getIfscCode());
                    paymentRepository.save(payment);
                    booking.setStatus("Payed");

                    // Add the carInfoId to the list
                    carInfoIds.add(booking.getCarInfo().getId());
                    bookingIds.add(booking.getId());
                }

                // Convert the list of carInfoIds to a comma-separated string
                String carInfoIdsString = carInfoIds.stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(", "));

                String bookingIdsString = carInfoIds.stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(", "));

                // Save the carInfoIds to the payment table
                Payment payment = new Payment();
                payment.setUser(user);
                payment.setAmount(totalBookingAmount);
                payment.setPaymentDate(LocalDateTime.now());
                payment.setPaymentStatus("success");
                payment.setAccountHolderName(paymentDetails.getAccountHolderName());
                payment.setAccountNumber(paymentDetails.getAccountNumber());
                payment.setIfscCode(paymentDetails.getIfscCode());
                payment.setCarInfoIds(carInfoIdsString);
                payment.setBookingIds(bookingIdsString);
                paymentRepository.save(payment);
                bookingRepository.saveAll(userBookings);
                return ResponseEntity.ok("Payment successful");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No unpaid bookings found for the user");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
    }

    public PaymentDto getPaymentDetailsForUser(long userId) {
        Optional<Users> optionalUser = userRepository.findById(userId);

        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            List<Payment> userPayments = paymentRepository.findByUser(user);

            if (!userPayments.isEmpty()) {
                Payment latestPayment = userPayments.stream()
                        .max(Comparator.comparing(Payment::getPaymentDate))
                        .orElseThrow(() -> new IllegalStateException("No payments found for the user"));

                return new PaymentDto(
                        user.getId(),
                        latestPayment.getPaymentId(),
                        latestPayment.getAmount(),
                        latestPayment.getPaymentDate(),
                        latestPayment.getPaymentStatus()
                );
            } else {
                throw new IllegalStateException("No payments found for the user");
            }
        } else {
            throw new IllegalArgumentException("User not found");
        }
    }


}

////    public void saveCarBrand(CarBrandData carBrandData) {
////        CarBrandInfo carBrandInfo = new CarBrandInfo();
////        carBrandInfo.setCarBrandName(carBrandData.getCarBrandName());
////        carBrandRepository.save(carBrandInfo);
////    }
////
////    public ResponseEntity<String> updateCarBrand(long id, CarBrandData updatedBrandInfo) {
////        if (carBrandRepository.existsById(id)) {
////            CarBrandInfo brandInfo = carBrandRepository.findById(id).orElse(null);
////            if (brandInfo != null) {
////                brandInfo.setCarBrandName(updatedBrandInfo.getCarBrandName());
////                carBrandRepository.save(brandInfo);
////                return ResponseEntity.ok("Car brand updated successfully.");
////            }
////        }
////        return ResponseEntity.badRequest().body("Invalid car brand ID.");
////    }
////
////    public ResponseEntity<String> deleteCarBrand(long id) {
////        if (carBrandRepository.existsById(id)) {
////            CarBrandInfo carBrandInfo = carBrandRepository.findById(id).orElse(null);
////            if (carBrandInfo != null) {
////                List<CarInfo> carInfos = carBrandInfo.getCar();
////                if (carInfos != null) {
////                    carInfos.forEach(carInfo -> carInfo.setCarBrand(null));
////                    carInfoRepository.saveAll(carInfos);
////                }
////                carBrandRepository.deleteById(id);
////                return ResponseEntity.ok("Car brand and associated car info deleted successfully.");
////            }
////        }
////        return ResponseEntity.badRequest().body("Invalid car brand ID.");
////    }
////
////    public ResponseEntity<String> addCarInfo(long brandId, CarInfoDto carInfoDto) {
////        CarBrandInfo carBrand = carBrandRepository.findById(brandId).orElse(null);
////        CarInfo carInfo = new CarInfo();
////        if (carBrand != null) {
////            carInfo.setCarBrand(carBrand);
////            carInfo.setCarName(carInfoDto.getCarName());
////            carInfo.setAmount(carInfoDto.getAmount());
////            carInfo.setStock(carInfoDto.getStock());
////            CarInfo car = carInfoRepository.save(carInfo);
////            return ResponseEntity.ok("Car Details added Successfully");
////        } else {
////            return ResponseEntity.badRequest().body("Invalid brand ID.");
////        }
////    }
////
////    public ResponseEntity<String> updateCarsInfo(long id, UpdateCarInfo updateCarInfo) {
////        if (carInfoRepository.existsById(id)) {
////            CarInfo carInfo = carInfoRepository.findById(id).orElse(null);
////            if (carInfo != null) {
////                carInfo.setCarName(updateCarInfo.getCarName());
////                carInfo.setAmount(updateCarInfo.getAmount());
////                carInfo.setStock(updateCarInfo.getStock());
////                carInfoRepository.save(carInfo);
////                return ResponseEntity.ok("Car Info  updated successfully.");
////            }
////        }
////        return ResponseEntity.badRequest().body("Invalid car  ID.");
////
////    }
////
////    public ResponseEntity<String> deleteCars(long id) throws UserNotFoundException {
////        Optional<CarInfo> car = carInfoRepository.findById(id);
////        if (car.isEmpty()) {
////            throw new UserNotFoundException("User Not Found\t" + id);
////        }
////        carInfoRepository.deleteById(id);
////        return ResponseEntity.ok("Car Details Deleted successfully");
////
////    }
////
////
////    public List<UserData> getAllCustomersInfo() {
////        List<Users> usersDetails = userRepository.findAll();
////        return usersDetails.stream()
////                .map(UserData::new)
////                .collect(Collectors.toList());
////    }