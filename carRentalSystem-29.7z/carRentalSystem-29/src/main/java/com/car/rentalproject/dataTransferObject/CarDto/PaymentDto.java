package com.car.rentalproject.dataTransferObject.CarDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDto {
    private long userId;
    private long paymentId;
    private double amount;
    private LocalDateTime paymentDate;
    private String paymentStatus;
}
