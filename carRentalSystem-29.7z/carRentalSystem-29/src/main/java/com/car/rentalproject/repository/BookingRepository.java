package com.car.rentalproject.repository;



import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface BookingRepository extends JpaRepository<Booking,Long> {

    Optional<Booking> findByIdAndUsersId(long bookingId, long userId);

    List<Booking> findByUsersId(long userId);

    List<Booking> findByUsers(Users user);


    List<Booking> findByUsersAndStatusNot(Users user, String payed);

}