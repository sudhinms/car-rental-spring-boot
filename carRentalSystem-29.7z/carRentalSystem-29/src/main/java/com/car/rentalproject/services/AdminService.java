package com.car.rentalproject.services;

import com.car.rentalproject.dataTransferObject.CarDto.BookingData;
import com.car.rentalproject.dataTransferObject.CarDto.CarBrandData;
import com.car.rentalproject.dataTransferObject.CarDto.CarInfoDto;
import com.car.rentalproject.dataTransferObject.CarDto.UpdateCarInfo;
import com.car.rentalproject.dataTransferObject.UserDto.UserData;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.CarBrandInfo;
import com.car.rentalproject.entity.CarInfo;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
public class AdminService {
    @Autowired
    private CarBrandInfoRepository carBrandRepository;
    @Autowired
    private CarInfoRepository carInfoRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserServices userServices;

    public void saveCarBrand(CarBrandData carBrandData) {
        CarBrandInfo carBrandInfo = new CarBrandInfo();
        carBrandInfo.setCarBrandName(carBrandData.getCarBrandName());
        carBrandRepository.save(carBrandInfo);
    }

    public ResponseEntity<String> updateCarBrand(long id, CarBrandData updatedBrandInfo) {
        if (carBrandRepository.existsById(id)) {
            CarBrandInfo brandInfo = carBrandRepository.findById(id).orElse(null);
            if (brandInfo != null) {
                brandInfo.setCarBrandName(updatedBrandInfo.getCarBrandName());
                carBrandRepository.save(brandInfo);
                return ResponseEntity.ok("Car brand updated successfully.");
            }
        }
        return ResponseEntity.badRequest().body("Invalid car brand ID.");
    }

    public ResponseEntity<String> deleteCarBrand(long id) {
        if (carBrandRepository.existsById(id)) {
            CarBrandInfo carBrandInfo = carBrandRepository.findById(id).orElse(null);
            if (carBrandInfo != null) {
                List<CarInfo> carInfos = carBrandInfo.getCar();
                if (carInfos != null) {
                    carInfos.forEach(carInfo -> carInfo.setCarBrand(null));
                    carInfoRepository.saveAll(carInfos);
                }
                carBrandRepository.deleteById(id);
                return ResponseEntity.ok("Car brand and associated car info deleted successfully.");
            }
        }
        return ResponseEntity.badRequest().body("Invalid car brand ID.");
    }

    public ResponseEntity<String> addCarInfo(long brandId, CarInfoDto carInfoDto) {
        CarBrandInfo carBrand = carBrandRepository.findById(brandId).orElse(null);
        CarInfo carInfo = new CarInfo();
        if (carBrand != null) {
            carInfo.setCarBrand(carBrand);
            carInfo.setCarName(carInfoDto.getCarName());
            carInfo.setAmount(carInfoDto.getAmount());
            carInfo.setStock(carInfoDto.getStock());
            carInfoRepository.save(carInfo);
            return ResponseEntity.ok("Car Details added Successfully");
        } else {
            return ResponseEntity.badRequest().body("Invalid brand ID.");
        }
    }

    public ResponseEntity<String> updateCarsInfo(long id, UpdateCarInfo updateCarInfo) {
        if (carInfoRepository.existsById(id)) {
            CarInfo carInfo = carInfoRepository.findById(id).orElse(null);
            if (carInfo != null) {
                carInfo.setCarName(updateCarInfo.getCarName());
                carInfo.setAmount(updateCarInfo.getAmount());
                carInfo.setStock(updateCarInfo.getStock());
                carInfoRepository.save(carInfo);
                return ResponseEntity.ok("Car Info  updated successfully.");
            }
        }
        return ResponseEntity.badRequest().body("Invalid car  ID.");

    }
    public  ResponseEntity<?> updateStock(long carId,int stock){
    Optional<CarInfo> car=carInfoRepository.findById(carId);
        if(car.isPresent()){
        CarInfo carInfo=car.get();
        carInfo.setStock(carInfo.getStock()+stock);
        carInfoRepository.save(carInfo);
        return new ResponseEntity<>("Stock updated successfully", HttpStatus.OK);
    }
        return new ResponseEntity<>("Car not found", HttpStatus.NOT_FOUND);
}

    public ResponseEntity<String> deleteCars(long id) throws UserNotFoundException {
        Optional<CarInfo> car = carInfoRepository.findById(id);
        if (car.isEmpty()) {
            throw new UserNotFoundException("User Not Found\t" + id);
        }
        carInfoRepository.deleteById(id);
        return ResponseEntity.ok("Car Details Deleted successfully");

    }
    public ResponseEntity<?> deleteUser(long userId) {
        Optional<Users> user = userRepository.findById(userId);
        if (Objects.equals(user.get().getRoles(), "ROLE_USER")) {
            try {
                userServices.deleteUser(userId);
                return ResponseEntity.ok("User deleted successfully");
            } catch (Exception e) {
                return ResponseEntity.status(500).body("Failed to delete user: " + e.getMessage());
            }
        }
        return ResponseEntity.ok("ADMIN CAN NOT REPLACEABLE ");
    }


    public List<UserData> getAllCustomersInfo() {
        List<Users> usersDetails = userRepository.findAll();
        return usersDetails.stream()
                .map(UserData::new)
                .collect(Collectors.toList());
    }

    public List<BookingData> mapToBookingInfoList(List<Booking> bookings) {
        return bookings.stream()
                .map(BookingData::new)
                .collect(Collectors.toList());
    }

}
