package com.car.rentalproject.controller;

import com.car.rentalproject.dataTransferObject.CarDto.BookingData;
import com.car.rentalproject.dataTransferObject.CarDto.CarBrandData;
import com.car.rentalproject.dataTransferObject.CarDto.CarInfoDto;
import com.car.rentalproject.dataTransferObject.CarDto.UpdateCarInfo;
import com.car.rentalproject.dataTransferObject.UserDto.UserData;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.CarInfo;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.BookingRepository;
import com.car.rentalproject.repository.CarInfoRepository;
import com.car.rentalproject.repository.UserRepository;
import com.car.rentalproject.services.AdminService;
import com.car.rentalproject.services.BookingService;
import com.car.rentalproject.services.UserServices;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/admin")
public class AdminController {


    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserServices userServices;
    @Autowired
    private AdminService adminService;
    @Autowired
    private CarInfoRepository carInfoRepository;
    @Autowired
    private UserRepository userRepository;


    @PostMapping("brand/add")
    public ResponseEntity<String> addCarBrand(@RequestBody CarBrandData carBrandData) {
        try {
            adminService.saveCarBrand(carBrandData);
            return ResponseEntity.ok("Brand added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to add brand: " + e.getMessage());
        }
    }


    @PutMapping("/brand/update/{id}")
    public ResponseEntity<String> updateCarBrand(@PathVariable long id, @RequestBody CarBrandData updatedBrandInfo) {

        return adminService.updateCarBrand(id, updatedBrandInfo);
    }


    @DeleteMapping("brand/delete/{id}")
    public ResponseEntity<String> deleteCarBrand(@PathVariable long id) {

        return adminService.deleteCarBrand(id);
    }


    @PostMapping("/addCars/{brandId}")
    public ResponseEntity<String> addCarInfo(@PathVariable long brandId, @RequestBody CarInfoDto carInfoDto) {

        return adminService.addCarInfo(brandId, carInfoDto);
    }
    @PutMapping("/updateCars/{carInfoId}")
    public ResponseEntity<String> updateCars(@PathVariable long carInfoId, @RequestBody UpdateCarInfo updateCarInfo){
        return adminService.updateCarsInfo(carInfoId,updateCarInfo);
    }
    @PatchMapping("/stockUpdate/{carId}/{stock}")
    public ResponseEntity<?> UpdateStock(@PathVariable long carId,@PathVariable int stock){
       return adminService.updateStock(carId,stock);
    }

    @DeleteMapping("/deleteCars/{carInfoId}")
    public ResponseEntity<String>deleteCars(@PathVariable long carInfoId) throws UserNotFoundException {
        return adminService.deleteCars(carInfoId);
    }

    @DeleteMapping("user/delete/{userId}")
    public ResponseEntity<?> deleteUser(@PathVariable long userId) {
       return adminService.deleteUser(userId);
    }

    @GetMapping("view/customers")
    public ResponseEntity<List<UserData>> getAllCustomersInfo() {
        List<UserData> customerInfoList = adminService.getAllCustomersInfo();
        return ResponseEntity.ok(customerInfoList);
    }

    @GetMapping("view/booking")
    public List<BookingData> viewBookings() {
        List<Booking> bookings = bookingRepository.findAll();
        return adminService.mapToBookingInfoList(bookings);
    }


}

