package com.car.rentalproject.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarReturnDetails {
    private long id;
    private Date returnDate;
    private String status;
}
