package com.car.rentalproject.exceptions;

public class BookingNotFoundException extends Throwable {
    public BookingNotFoundException(String s) {
        super(s);
    }
}
