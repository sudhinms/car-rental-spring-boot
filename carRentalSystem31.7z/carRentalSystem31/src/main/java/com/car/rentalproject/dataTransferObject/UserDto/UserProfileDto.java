package com.car.rentalproject.dataTransferObject.UserDto;

import com.car.rentalproject.entity.Users;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserProfileDto {

    private long id;
    private String name;
    private int age;
    private String email;
    private Date date;
    private String bookingStatus;
    private byte[] profileImage;

    public UserProfileDto(Users users) {
        this.id= users.getId();
        this.date=users.getDate();
        this.name= users.getName();
        this.age= users.getAge();
        this.email= users.getEmail();
        //this.bookingStatus= users.getBookingStatus();
        this.profileImage= users.getProfileImage();

    }
}
