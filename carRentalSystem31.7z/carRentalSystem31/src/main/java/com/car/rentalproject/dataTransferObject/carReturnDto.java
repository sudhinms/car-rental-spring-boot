package com.car.rentalproject.dataTransferObject;

import java.util.Date;

public class carReturnDto {
    private Date date;
}
