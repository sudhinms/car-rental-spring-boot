package com.car.rentalproject.repository;

import com.car.rentalproject.entity.CarBrandInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CarBrandInfoRepository extends JpaRepository<CarBrandInfo,Long> {
}