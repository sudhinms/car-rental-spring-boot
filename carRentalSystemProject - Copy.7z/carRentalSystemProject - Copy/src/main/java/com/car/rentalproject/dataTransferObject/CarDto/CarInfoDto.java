package com.car.rentalproject.dataTransferObject.CarDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarInfoDto {
    private String carName;
    private long amount;
    private long stock;
}
