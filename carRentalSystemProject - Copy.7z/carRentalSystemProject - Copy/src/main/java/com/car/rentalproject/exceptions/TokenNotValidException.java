package com.car.rentalproject.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)

public class TokenNotValidException extends Exception {
    public TokenNotValidException(String message){
        super(message);
    }

}
