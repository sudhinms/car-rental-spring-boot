package com.car.rentalproject.dataTransferObject.CarDto;


import lombok.AllArgsConstructor;
        import lombok.Data;
        import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarBrandInfoData {

    private long brandId;
    private String brandName;

    // Constructors, getters, and setters



    // Getters and setters...
}