package com.car.rentalproject.services;

import com.car.rentalproject.dataTransferObject.UserDto.PasswordDto;
import com.car.rentalproject.dataTransferObject.UserDto.UserUpdateDto;
import com.car.rentalproject.dataTransferObject.UserDto.UserData;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.Payment;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.FileReadWriteException;
import com.car.rentalproject.exceptions.PasswordNotMatchException;
import com.car.rentalproject.repository.PaymentRepository;
import com.car.rentalproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServices {
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PaymentRepository paymentRepository;


    public ResponseEntity<String> registration(Users users, MultipartFile file) throws IOException, FileReadWriteException {
        if(isUserAlreadyPresent(users.getEmail())){
            return new ResponseEntity<>("There is an existing user with same username ....Please try login...",HttpStatus.ACCEPTED);
        }
        users.setPassword(passwordEncoder.encode(users.getPassword()));
        return (ResponseEntity<String>) validateAndSetImage(users,file);

    }
    private ResponseEntity<?> validateAndSetImage(Users users, MultipartFile file) throws FileReadWriteException {
        if(file!=null){
            try {
                if (!file.getContentType().startsWith("image/")) {
                    return ResponseEntity.badRequest().body("Only images are allowed");
                }
                users.setProfileImage(file.getBytes());
            }catch (Exception e){
                throw new FileReadWriteException("Cant write image data to db");
            }
        }
        userRepository.save(users);
        return new ResponseEntity<>("Registered Successfully",HttpStatus.CREATED);
    }
    public boolean isUserAlreadyPresent(String email){
        return userRepository.findByEmail(email).isPresent();
    }

    public ResponseEntity<Users> updateUserData(UserUpdateDto userdata, String email, MultipartFile file) throws IOException, FileReadWriteException {
        Optional<Users> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isPresent()) {
            Users existingUser = optionalUser.get();
            existingUser.setName(userdata.getName());
            existingUser.setAge(userdata.getAge());
            existingUser.setAddress(userdata.getAddress());
            existingUser.setDate(userdata.getDate());
            return (ResponseEntity<Users>) validateAndSetImage(existingUser,file);
            } else {
                return ResponseEntity.notFound().build();
            }
        }



    public List<UserData> getUser(Optional<Users> user) {
        return user.stream()
                .map(UserData::new)
                .collect(Collectors.toList());

    }

    public ResponseEntity<?> updatePassword(String email, PasswordDto passwordDto) throws PasswordNotMatchException {
        Users userInfo = userRepository.findByEmail(email).get();
        if (!passwordEncoder.matches(passwordDto.getOldPassword(), userInfo.getPassword())) {
            throw new PasswordNotMatchException("Incorrect password for user : " + email);
        }
        if (!Objects.equals(passwordDto.getNewPassword(), passwordDto.getConfirmPassword())) {
            throw new PasswordNotMatchException("Confirm password not match with new password");
        }
        userInfo.setPassword(passwordEncoder.encode(passwordDto.getNewPassword()));
        userRepository.save(userInfo);
        return new ResponseEntity<>("Password updated successfully..", HttpStatus.OK);
    }

    public ResponseEntity<String> deleteUser(long userId) {
        Users user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            return ResponseEntity.status(404).body("User not found");
        }
        List<Booking> userBookings = user.getBookings();
        if (!userBookings.isEmpty()) {
            return ResponseEntity.status(400).body("Cannot delete user with existing bookings");
        }
        userRepository.deleteById(userId);
        return ResponseEntity.ok("User deleted successfully");
    }



}
