package com.car.rentalproject.exceptions;

public class EmptyListException extends Throwable {
    public EmptyListException(String message){
        super(message);
    }
}
