package com.car.rentalproject.entity;

 import jakarta.persistence.*;
 import lombok.AllArgsConstructor;
 import lombok.Data;
 import lombok.NoArgsConstructor;

 import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long paymentId;

    @ManyToOne
    @JoinColumn(name = "car_info_id")
    private CarInfo carInfo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private Users user;

    private double amount;

    private LocalDateTime paymentDate;

    private LocalDateTime bookingDate;


    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;

    private String paymentStatus;
}

