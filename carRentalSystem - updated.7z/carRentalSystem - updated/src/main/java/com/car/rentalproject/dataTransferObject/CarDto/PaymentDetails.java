package com.car.rentalproject.dataTransferObject.CarDto;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDetails {
    @Column(nullable = false)
    private String accountHolderName;
    @Size(min=9,max=12)
    @Column(nullable = false)
    private long accountNumber;
    @Column(nullable = false)
    private int pin;
    @Column(nullable = false)
    private long  ifscCode;
    @Column(nullable = false)
    private String bankBranchName;
}
