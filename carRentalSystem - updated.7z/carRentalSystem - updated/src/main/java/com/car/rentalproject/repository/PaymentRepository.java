package com.car.rentalproject.repository;

import com.car.rentalproject.entity.Payment;
import com.car.rentalproject.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentRepository extends JpaRepository<Payment,Long> {
    boolean existsByUser(Users user);

}
