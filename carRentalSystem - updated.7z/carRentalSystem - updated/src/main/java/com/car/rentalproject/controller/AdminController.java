package com.car.rentalproject.controller;

import com.car.rentalproject.dataTransferObject.CarDto.BookingData;
import com.car.rentalproject.dataTransferObject.CarDto.CarBrandData;
import com.car.rentalproject.dataTransferObject.CarDto.CarInfoDto;
import com.car.rentalproject.dataTransferObject.CarDto.UpdateCarInfo;
import com.car.rentalproject.dataTransferObject.UserDto.UserData;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.CarBrandInfo;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.BookingRepository;
import com.car.rentalproject.repository.CarBrandInfoRepository;
import com.car.rentalproject.repository.CarInfoRepository;
import com.car.rentalproject.repository.UserRepository;
import com.car.rentalproject.services.CarService;
import com.car.rentalproject.services.UserServices;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private CarBrandInfoRepository carBrandInfoRepository;

    @Autowired
    private CarInfoRepository carInfoRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CarService carService;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserServices userServices;


    @PostMapping("brand/add")
    public ResponseEntity<String> addCarBrand(@RequestBody CarBrandData carBrandData) {
        try {
            carService.saveCarBrand(carBrandData);
            return ResponseEntity.ok("Brand added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to add brand: " + e.getMessage());
        }
    }


    @PutMapping("/brand/update/{id}")
    public ResponseEntity<String> updateCarBrand(@PathVariable long id, @RequestBody CarBrandData updatedBrandInfo) {

        return carService.updateCarBrand(id, updatedBrandInfo);
    }


    @DeleteMapping("brand/delete/{id}")
    public ResponseEntity<String> deleteCarBrand(@PathVariable long id) {

        return carService.deleteCarBrand(id);
    }


    @PostMapping("/addCars/{brandId}")
    public ResponseEntity<String> addCarInfo(@PathVariable long brandId, @RequestBody CarInfoDto carInfoDto) {

        return carService.addCarInfo(brandId, carInfoDto);
    }
    @PutMapping("/updateCars/{carInfoId}")
    public ResponseEntity<String> updateCars(@PathVariable long carInfoId, @RequestBody UpdateCarInfo updateCarInfo){
        return carService.updateCarsInfo(carInfoId,updateCarInfo);
    }

    @DeleteMapping("/deleteCars/{carInfoId}")
    public ResponseEntity<String>deleteCars(@PathVariable long carInfoId) throws UserNotFoundException {
        return carService.deleteCars(carInfoId);
    }

    @DeleteMapping("user/delete/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable long userId) {
        try {
            userServices.deleteUser(userId);
            return ResponseEntity.ok("User deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to delete user: " + e.getMessage());
        }
    }

    @GetMapping("view/customers")
    public ResponseEntity<List<UserData>> getAllCustomersInfo() {
        List<UserData> customerInfoList = carService.getAllCustomersInfo();
        return ResponseEntity.ok(customerInfoList);
    }

    @GetMapping("view/booking")
    public List<BookingData> viewBookings() {
        List<Booking> bookings = bookingRepository.findAll();
        return carService.mapToBookingInfoList(bookings);
    }


}

