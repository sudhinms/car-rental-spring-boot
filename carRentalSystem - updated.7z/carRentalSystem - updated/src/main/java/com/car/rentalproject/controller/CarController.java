package com.car.rentalproject.controller;

import com.car.rentalproject.dataTransferObject.CarDto.BookingData;
import com.car.rentalproject.dataTransferObject.CarDto.PaymentDetails;
import com.car.rentalproject.entity.Booking;
import com.car.rentalproject.entity.CarInfo;
import com.car.rentalproject.entity.Users;
import com.car.rentalproject.exceptions.ProductNotFoundException;
import com.car.rentalproject.exceptions.UserNotFoundException;
import com.car.rentalproject.repository.BookingRepository;
import com.car.rentalproject.repository.CarInfoRepository;
import com.car.rentalproject.repository.UserRepository;
import com.car.rentalproject.security.JwtServices;
import com.car.rentalproject.services.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/book")

public class CarController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CarService carService;
    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CarInfoRepository carInfoRepository;

    @Autowired
    private JwtServices jwtServices;


    @PostMapping("/car/{customerId}/{carInfoId}")
    public ResponseEntity<String> bookCar(@PathVariable long customerId, @PathVariable long carInfoId) throws UserNotFoundException {
        return carService.bookCar(customerId, carInfoId);
    }

    @GetMapping("/userBooking")
    public List<BookingData> getBookingInfoByCustomer(@RequestHeader(name = "Authorization") String token) {
        String currentUserEmail = jwtServices.extractUsernameFromToken(token.substring(7));
        try {
            long userId = userRepository.findByEmail(currentUserEmail).get().getId();
            List<Booking> bookings = bookingRepository.findByUsersId(userId);
            return carService.mapToBookingInfoList(bookings);
        } catch (StackOverflowError e) {
            System.out.println("The stack overflowed.");
            return new ArrayList<BookingData>();
        }
    }

    @DeleteMapping("/cancel/{userId}/{bookingId}")
    public ResponseEntity<String> deleteBooking(@PathVariable long userId, @PathVariable long bookingId) {
        return carService.deleteBooking(userId, bookingId);
    }

    @PostMapping("/payment")
    public ResponseEntity<String> performPayment(@RequestHeader(name = "Authorization") String token, @RequestBody PaymentDetails paymentDetails) {
        String currentUserEmail = jwtServices.extractUsernameFromToken(token.substring(7));
        return carService.userPayment(currentUserEmail,paymentDetails);
    }

}



