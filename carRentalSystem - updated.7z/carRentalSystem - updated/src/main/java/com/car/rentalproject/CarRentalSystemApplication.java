package com.car.rentalproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRentalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarRentalSystemApplication.class, args);
	}

}
//Car Rental Project
//Modules and Functionalities
//There are two main roles in this application. One is the Admin and another one is the user(customer).
//1) Admin
//	Admin 	can ADD/VIEW/UPDATE/DELETE Car Brands.
//	Admin 	can ADD/VIEW/UPDATE/DELETE Vehicle.
//	It 	can VIEW the registered customers.
//	Admin 	can VIEW the Booking Report.
//2) Customer
//	Customers 	can VIEW the list of cars based on brands.
//	Customers 	can Book a car.
//	It 	can VIEW the Booking report.
//	Customers 	can Download the Receipt also.
//Note: The login, registration, profile section, and change password are common to all the users in the system.
//Must use spring security,Custom Error handling should be there and passwords must be encrypted .