package com.car.rentalproject.entity;

import com.car.rentalproject.dataTransferObject.CarDto.CarDetails;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarBrandInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String carBrandName;
    @OneToMany(targetEntity = CarInfo.class,cascade = CascadeType.ALL)
    @JoinColumn(name="carBrandId",referencedColumnName = "id")
    private List<CarInfo> car;

    public List<CarDetails> getCarDetails() {
        return car.stream()
                .map(carInfo -> new CarDetails(this.id, this.carBrandName, carInfo.getId(), carInfo.getCarName(),carInfo.getAmount()))
                .toList();
    }
}