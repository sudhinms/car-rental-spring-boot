package com.car.rentalproject.dataTransferObject.UserDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserProfileDto {

    private long id;
    private String name;
    private int age;
    private String email;
    private Date date;
    private String bookingStatus;
    private String password;
    private byte[] profileImage;
}
