package com.car.rentalproject.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CarInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String carName;
    private long stock;
    private long amount;

    @ManyToOne
    @JoinColumn(name = "carBrandId")
    private CarBrandInfo carBrand;

    @OneToMany(mappedBy = "carInfo", cascade = CascadeType.ALL)
    private List<Booking> bookings;


    @OneToMany(mappedBy = "carInfo", cascade = CascadeType.ALL)
    private List<Payment> payments;
}