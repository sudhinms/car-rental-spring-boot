package com.car.rentalproject.dataTransferObject.CarDto;

import jakarta.validation.constraints.Future;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class CarReturnDto {
   @Future(message = "Return date should be in the future")
   private Date returnDate;

}
