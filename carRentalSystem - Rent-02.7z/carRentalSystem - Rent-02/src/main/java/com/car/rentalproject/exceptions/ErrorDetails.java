package com.car.rentalproject.exceptions;

import java.time.LocalDateTime;

public class ErrorDetails {
    private LocalDateTime timestamp;

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "ErrorDetails{" +
                "timestamp=" + timestamp +
                ", message='" + message + '\'' +
                ", details='" + details + '\'' +
                '}';
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetails() {
        return details;
    }

    public String getMessage() {
        return message;
    }

    private String message;

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    private String details;

    public ErrorDetails(LocalDateTime timestamp,String message,String details) {
        this.timestamp = timestamp;
        this.message=message;
        this.details=details;
    }
}

