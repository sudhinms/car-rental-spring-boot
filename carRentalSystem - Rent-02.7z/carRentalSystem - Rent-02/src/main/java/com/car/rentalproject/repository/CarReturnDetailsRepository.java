package com.car.rentalproject.repository;

import com.car.rentalproject.entity.CarReturnDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CarReturnDetailsRepository extends JpaRepository<CarReturnDetails,Long> {
    Optional<CarReturnDetails> findByBookingId(long bookingId);

   // Optional<CarReturnDetails> findByUserId(long userId);


    //void deleteByBookingId(long bookingId);

   // void deleteById(Optional<CarReturnDetails> optionalReturnProduct);

}
