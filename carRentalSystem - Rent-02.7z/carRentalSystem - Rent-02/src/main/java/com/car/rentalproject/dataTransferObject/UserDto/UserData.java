package com.car.rentalproject.dataTransferObject.UserDto;


import com.car.rentalproject.entity.Users;
import lombok.AllArgsConstructor;
        import lombok.Data;
        import lombok.NoArgsConstructor;
        import java.sql.Date;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserData {


    private long id;
    private String name;
    private int age;
    private String email;
    private Date date;


    public UserData(Users users) {
        this.id=users.getId();
        this.name=users.getName();
        this.age=users.getAge();
        this.email=users.getEmail();
        this.date=users.getDate();


    }



}